public class cafeOrderTest {
    public static void main(String[] args) {
        cafeOrder order1 = new cafeOrder("Coffee", 2.50);
        cafeOrder order2 = new cafeOrder("Tea", 1.50, 2);
        System.out.println("Cafe Order Bills:\n----------------------------");
        order1.printbill();
        order2.printbill();
    
}
